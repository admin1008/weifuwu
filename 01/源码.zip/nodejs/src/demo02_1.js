// nodejs里自带，导出模块, add方法导出去
exports.add = function(a, c) {
    return a + c;
}