//require 导入外部js, 导入内置的模块
var logic = require('./demo02_1')

console.log(logic.add(100, 200));