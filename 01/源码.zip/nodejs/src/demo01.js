var a = 100;
var c = 200;

function add(a, c) {
    return a + c;
}
// Sysstem.out.println()
console.log(add(a, c));