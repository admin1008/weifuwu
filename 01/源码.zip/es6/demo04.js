var logic = require('./demo04_1')

console.log(logic.add(100, 200));