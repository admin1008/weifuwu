let fn0 = function() {
        console.log("调用了fn0........")
    }
    // 导出对象,简化写法
export { fn0 }